#include <stdio.h>

int main(void)
{

	int i=0;

	while(1)
		if(i<10)
			printf("Hi\n");
		else
			break;
}